# Resume Based Questions #

## Questions ##

* Q1: Discuss a challenging problem you faced while working on a data science project and how did you solve it?
* Q2: Question: Explain a data science project that you are most proud to work on?

